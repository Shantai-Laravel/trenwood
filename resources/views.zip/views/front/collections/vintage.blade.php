@extends('front.app')
@section('content')
@include('front.layouts.header')
@if (count($set) > 0)
  <div class="collectionOne vintageOne">
    <div class="collectionDescktop homeContent">
      <section class="vintageSection">
        <div class="collectionInner">
              <div class="videoContainer">
                <video autoplay="autoplay" loop="loop" muted defaultMuted playsinline>
                  <source src="{{asset('videos/sets/'.$set->video->src)}}" type="video/mp4">
                </video>
              </div>
             <div  class=" asideBloc">
              <a href="{{url($lang->lang.'/catalog/'.$set->alias.'/'.$set->products->first()->alias)}}" class="imgBloc">
                @if ($set->products->first()->mainImage()->first())
                <img src="{{ asset('images/products/og/'.$set->products->first()->mainImage()->first()->src ) }}">
                @else
                    <img src="{{ asset('fronts/img/products/noimage.png') }}" alt="img-advice">
                @endif
              </a>
              <a href="{{url($lang->lang.'/catalog/'.$set->alias.'/'.$set->products->first()->alias)}}" class="titleNew">{{$set->products->first()->translationByLanguage($lang->id)->first()->name}}</a>
              <p>
                {!! strip_tags($set->products->first()->translationByLanguage($lang->id)->first()->description) !!}
              </p>
              <div class="titleCollectionNew">
                  {{trans('front.home.vintage')}}
              </div>
              <a href="{{url($lang->lang.'/catalog/'.$set->alias)}}" class="buttShop">
                  {{trans('front.general.buyBtn')}}
              </a>
            </div>

        </div>
      </section>
    </div>
    <div class="collectionsMobile">
      <div class="vintageMobile">
        <div class="row">
          <div class="col-12">
            @if ($set->mainPhoto)
                <img id="prOneBig1" class="noneMobile" src="{{ asset('images/sets/og/'.$set->mainPhoto->src ) }}">
            @else
                <img class="noneMobile" src="{{ asset('fronts/img/products/noimage.png') }}" alt="img-advice">
            @endif
            <div class="videoBlock">
              <video width="100%" height="auto" src="{{asset('videos/sets/'.$set->video->src)}}" autoplay muted loop>
              </video>
              <div class="zaglushka"></div>
            </div>
            <div class="title">{{$set->translationByLanguage($lang->id)->first()->name}}</div>
            {{-- <p>{{$set->translationByLanguage($lang->id)->first()->description}}</p> --}}
            <a href="{{url($lang->lang.'/catalog/'.$set->alias)}}" class="buttShop">
              {{trans('front.general.buyBtn')}}
            </a>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-auto">
          <div class="crumbs">
            <ul>
              <li><a href="{{url($lang->lang)}}">{{trans('front.general.homePage')}}</a> / </li>
              <li><a href="{{url($lang->lang.'/catalog/'.$set->alias)}}">{{$set->translationByLanguage($lang->id)->first()->name}}</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="collectionDescription">
        <h3 class="titleDescr">{{$set->translationByLanguage($lang->id)->first()->name}}</h3>
        <div class="container">
          <p>{{$set->translationByLanguage($lang->id)->first()->description}}</p>
        </div>
    </div>
    <div class="collectionOneItems">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-7 col-md-6 col-12">
              @if (count($set->photos) > 0)
                <div class="row justify-content-center">
                  <div class="col-12">
                    <div class="mainSlide">
                      @foreach ($set->photos as $image)
                        <div>
                          <img class="zoom" src="{{asset('images/sets/og/'.$image->src)}}" alt="" data-zoom-image="{{asset('images/sets/og/'.$image->src)}}">
                        </div>
                      @endforeach
                    </div>
                  </div>
                  <div class="col-md-10 col-12">
                    <div class="slideNav">
                      @foreach ($set->photos as $image)
                        <div>
                          <img src="{{asset('images/sets/og/'.$image->src)}}" alt="">
                        </div>
                      @endforeach
                    </div>
                  </div>
                </div>
              @endif
          </div>
          <div class="col-lg-5 col-md-6 col-12 subproducts">
            @include('front.inc.products')
          </div>
        </div>
      </div>
    </div>
  </div>
@endif
@include('front.layouts.footer')
@include('front.modals.modals')
@stop
