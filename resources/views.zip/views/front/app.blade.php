<!DOCTYPE html>
<html lang="{{$lang->lang}}">

<head>
  <meta charset="utf-8">
  <meta name="robots" content="nofollow,noindex">
  <meta name="_token" content="{{ csrf_token() }}">
  <meta name="googlebot" content="noindex, nofollow">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Trenwood</title>
  <link rel="stylesheet" href="{{ asset('fronts/css/resets.css') }}">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="{{ asset('fronts/css/style.css?'.uniqid()) }}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  <script src='https://www.google.com/recaptcha/api.js'></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
</head>

<body>
  <div class="julia-zoom">
      <div class="closeZoomImg"></div>

     <img class="zoomImg" src='' width='100%' />
     <div id="controlZoomImg">
     </div>
  </div>
  <div id="cover">
    @yield('content')
  </div>

  @include('front.layouts.scripts')
</body>

</html>
